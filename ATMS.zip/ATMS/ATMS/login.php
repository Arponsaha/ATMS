<?php
session_start();


$conn = new mysqli('localhost', 'root', '', 'users');
if (!$conn) {
    echo 'not connect';
}

$empty_email = $empty_password= ''; 

if (isset($_POST['submit'])) {
    $user_email = $_POST['user_email'];
    $user_password = $_POST['user_password'];
    //$md5_user_password = md5($user_password);


    if (empty($user_email)) {
        $empty_email = 'Fill Up This Field';
    }
    if (empty($user_password)) {
        $empty_password = 'Fill Up This Field';
    }
    if (!empty($user_email) && !empty($user_password)) {
        echo $sql = "SELECT * FROM users WHERE user_email = '$user_email' AND user_password = '$user_password' ";
        $query = $conn->query($sql);
    
        if ($query->num_rows > 0) {
            $_SESSION['login'] = 'login success';
            // header('location:ticket.php');
            header('location: ticket.php');

        } else {
            echo 'Not Found';
        }
    }
    
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-4">

            </div>
            <div class="col-4" style="margin-top:100px">
            <?php
            if(isset($_GET['user_create'])){
                echo 'User created successfully.';
            }
            
            ?>
                <!-- <form action="login.php" method="POST"> -->
                <form action="login.php" method="POST">

                    <div class="mt-2">
                        <label class="form-label">Email</label>
                        <input type="text" class="form-control" name="user_email" value="<?php if(isset($_POST['Submit'])){echo $user_email;} ?>">
                        <?php if(isset($_POST['submit'])){ echo "<span class='text-danger'>".$empty_email."</span>";} ?>                    </div>
                    <div class="mt-2">
                        <label class="form-label">password</label>
                        <input type="password" class="form-control" name="user_password">
                        <?php if(isset($_POST['submit'])){ echo "<span class='text-danger'>".$empty_password."</span>";} ?>

                    </div>

                    <div class="mt-2">
                        <button class="btn btn-success" name="submit">Login</button>
                    </div>
                </form>
                <h5>Not Have Account? <a href="user.php">Register</a></h5>
            </div>
            <div class="col-4">

            </div>
        </div>

    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
