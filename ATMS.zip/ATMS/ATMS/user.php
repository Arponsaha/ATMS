<?php

$conn = new mysqli('localhost', 'root', '', 'users');
if(!$conn){
    echo 'not connect';
}
$empmsg_firstname = $empmsg_lastname = $empmsg_email = $empmsg_password = $empmsg_pass_again = '';

if (isset($_POST['Submit'])) {
    $user_first_name = $_POST['user_first_name'];
    $user_last_name = $_POST['user_last_name'];
    $user_email = $_POST['user_email'];
    $user_password = $_POST['user_password'];
    $user_password_again = $_POST['user_password_again'];

    

    if (empty($user_first_name)) {
        $empmsg_firstname = 'Fill up this field.';
    }
    if (empty($user_last_name)) {
        $empmsg_lastname = 'Fill up this field.';
    }
    if (empty($user_email)) {
        $empmsg_email = 'Fill up this field.';
    }
    if (empty($user_password)) {
        $empmsg_password = 'Fill up this field.';
    }
    if (empty($user_password_again)) {
        $empmsg_pass_again = 'Fill up this field.';
    }
    if (!empty($user_first_name) && !empty($user_last_name) && !empty($user_email) && !empty($user_password) && !empty($user_password_again)) {
        if ($user_password === $user_password_again) {
            $sql = "INSERT INTO users (`user_first_name`, `user_last_name`, `user_email`, `user_password`) VALUES ('$user_first_name', '$user_last_name', '$user_email', '$user_password')";
            if ($conn->query($sql) == TRUE) {
                header('location:login.php?user create');
            } else {
                echo 'Error: ' . $conn->error;
            }
        } else {
            echo 'Password does not match';
        }
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-4">

            </div>
            <div class="col-4" style="margin-top:100px">
                <form action="user.php" method="POST">
                    <div class="mt-2">
                        <label class="form-label">First Name</label>
                        <input type="text" class="form-control" name="user_first_name" value="<?php if(isset($_POST['Submit'])){echo $user_first_name;} ?>">

                        <?php if(isset($_POST['Submit'])){ echo "<span class='text-danger'>".$empmsg_firstname;"</span>";} ?>
                    </div>
                    <div class="mt-2">
                        <label class="form-label">Last Name</label>
                        <input type="text" class="form-control" name="user_last_name" value="<?php if(isset($_POST['Submit'])){echo $user_last_name;} ?>">
                        <?php if(isset($_POST['Submit'])){ echo "<span class='text-danger'>".$empmsg_lastname;"</span>";} ?>
                    </div>
                    <div class="mt-2">
                        <label class="form-label">Email</label>
                        <input type="text" class="form-control" name="user_email" value="<?php if(isset($_POST['Submit'])){echo $user_email;} ?>">
                        <?php if(isset($_POST['Submit'])){ echo "<span class='text-danger'>".$empmsg_email;"</span>";} ?>
                    </div>
                    <div class="mt-2">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="user_password">
                        <?php if(isset($_POST['Submit'])){ echo "<span class='text-danger'>".$empmsg_password;"</span>";} ?>
                    </div>
                    <div class="mt-2">
                        <label class="form-label">Password Again</label>
                        <input type="password" class="form-control" name="user_password_again">
                        <?php if(isset($_POST['Submit'])){ echo "<span class='text-danger'>".$empmsg_pass_again;"</span>";} ?>
                        
                    </div>
                    <div class="mt-2">
                        <button class="btn btn-success" name="Submit">Submit</button> 
                    </div>
                </form>
                <h5>Have an Account? <a href="login.php">Login</a></h5>

            </div>
            <div class="col-4">

            </div>
        </div>

    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
