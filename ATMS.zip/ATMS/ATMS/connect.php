<?php

$conn = new mysqli('localhost', 'root', '', 'users');
if (!$conn) {
    echo 'not connect';
}
?>