<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Air Ticket Booking</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<?php

include 'connect.php';

/*$sql = "SELECT id,p_name,p_age,p_sex,p_number,b_date FROM information_passenger";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      echo "id: " . $row["id"]. " - Name: " . $row["p_name"]. " " . $row["p_age"]. " " . $row["p_sex"]. "<br>";
    }
}
*/ // ei khane amar bujhar jonno kore rekhasi. kivaba data print korte hoy.

$sql = "SELECT count(*) as total FROM information_passenger";
$result = $conn->query($sql);
//echo "Total Seat= 100 <br>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      //echo "Total Booking Seat: " . $row["total"];
      //echo "<br>";
      $booking_seat_Total=$row["total"];
    }


}
$total_remaining_seat= 100- $booking_seat_Total;
//echo $booking_seat_Total;
 //echo "Total Remaining Seat :". 100 - $booking_seat_Total;

?>

    <div class="container mt-5">
        <img src="tic.jpg" alt="Air Logo" class="img-fluid mb-3" style="max-width: 100px;">

        <h2 class="mb-4">Air Ticket Booking</h2>

        <form id="bookingForm" action="pasenger.php" method="post">
            <div class="form-group">
                <label for="totalSeats">Total Seats:</label>
                <input type="number" class="form-control" id="totalSeats" name="totalSeats" value="100" disabled>
            </div>

            <div class="form-group">
                <label for="availableSeats">Available Seats:</label>
                <input type="number" class="form-control" id="availableSeats" name="availableSeats" value="<?php  echo $total_remaining_seat; ?>" disabled>
            </div>

            <button type="submit" class="btn btn-primary">Seat Booking</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- <script>
        document.addEventListener('DOMContentLoaded', function () {
            var totalSeats = 100;
            var availableSeats = 50;

            document.getElementById('totalSeats').value = totalSeats;
            document.getElementById('availableSeats').value = availableSeats;

            
            document.getElementById('bookingForm').addEventListener('submit', function (event) {
                event.preventDefault();
                

                
                this.submit();
            });
        });
    </script> -->
</body>
</html>
