<?php
session_start();

// $conn = new mysqli('localhost', 'root', '', 'users');
// if (!$conn) {
//     echo 'not connect';
// }

include 'connect.php';

$empty_name = $empty_age = $empty_sex = $empty_mobile = $empty_date = ''; 

if (isset($_POST['submit'])) {
    $p_name = $_POST['name'];
    $p_age = $_POST['age'];
    $p_sex = $_POST['sex'];
    $p_number = $_POST['mobileNumber'];
    $b_date = $_POST['bookingDate'];

    if (empty($p_name)) {
        $empty_name = 'Fill Up This Field';
    }
    if (empty($p_age)) {
        $empty_age = 'Fill Up This Field';
    }
    if (empty($p_sex)) {
        $empty_sex = 'Fill Up This Field';
    }
    if (empty($p_number)) {
        $empty_mobile = 'Fill Up This Field';
    }
    if (empty($b_date)) {
        $empty_date = 'Fill Up This Field';
    }

    if (!empty($p_name) && !empty($p_age) && !empty($p_sex) && !empty($p_number) && !empty($b_date)) {
        $sql = "INSERT INTO information_passenger (p_name, p_age, p_sex, p_number, b_date) VALUES ('$p_name', '$p_age', '$p_sex', '$p_number', '$b_date')";
        if ($conn->query($sql)) {
           
            header('location: booking.php');
            exit();
        } else {
            echo 'Error: ' . $sql . '<br>' . $conn->error;
        }
    }
}

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passenger Information</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

    <div class="container mt-5">
        <h2 class="mb-4">Passenger Information</h2>

        <form id="passengerForm" method="post">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control form-control-sm" id="name" name="name" required>
                <small class="text-danger"><?php echo $empty_name; ?></small>
            </div>

            <div class="form-group">
                <label for="age">Age:</label>
                <input type="number" class="form-control form-control-sm" id="age" name="age" required>
                <small class="text-danger"><?php echo $empty_age; ?></small>
            </div>

            <div class="form-group">
                <label for="sex">Sex:</label>
                <select class="form-control form-control-sm" id="sex" name="sex" required>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>
                <small class="text-danger"><?php echo $empty_sex; ?></small>
            </div>

            <div class="form-group">
                <label for="mobileNumber">Mobile Number:</label>
                <input type="tel" class="form-control form-control-sm" id="mobileNumber" name="mobileNumber" pattern="[0-9]{11}" required>
                <small class="form-text text-muted">Please enter a 11-digit mobile number.</small>
                <small class="text-danger"><?php echo $empty_mobile; ?></small>
            </div>

            <div class="form-group">
                <label for="bookingDate">Booking Date:</label>
                <input type="date" class="form-control form-control-sm" id="bookingDate" name="bookingDate" required>
                <small class="text-danger"><?php echo $empty_date; ?></small>
            </div>

            <button type="submit" name="submit" class="btn btn-primary btn-sm">Confirm Booking</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
